# android_intent_example

Demonstrates how to use the android_intent_plus plugin.

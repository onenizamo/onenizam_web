#!/bin/bash
cd example/android
./gradlew test -DflutterPath=$FLUTTER_HOME

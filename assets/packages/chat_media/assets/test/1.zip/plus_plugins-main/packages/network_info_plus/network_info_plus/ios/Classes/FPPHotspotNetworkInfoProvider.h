#import "FPPNetworkInfoProvider.h"
#import <Foundation/Foundation.h>

@interface FPPHotspotNetworkInfoProvider : NSObject <FPPNetworkInfoProvider>
@end

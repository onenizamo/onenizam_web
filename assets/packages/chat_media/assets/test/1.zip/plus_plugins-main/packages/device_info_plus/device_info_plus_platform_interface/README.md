# Device Info Plus Platform Interface

[![Flutter Community: device_info_plus_platform_interface](https://fluttercommunity.dev/_github/header/device_info_plus_platform_interface)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/device_info_plus_platform_interface.svg)](https://pub.dev/packages/device_info_plus_platform_interface)

A common platform interface for [`device_info_plus`](https://pub.dev/packages/device_info_plus).

## Usage

This package is already included as part of the `device_info_plus` package dependency, and will
be included when using `device_info_plus` as normal.

# battery_plus_example

Demonstrates how to use the [battery_plus plugin][1]

[1]: ../
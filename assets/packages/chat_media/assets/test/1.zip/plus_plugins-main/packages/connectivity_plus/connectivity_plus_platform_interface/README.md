# Connectivity Plus Platform Interface

[![Flutter Community: connectivity_plus_platform_interface](https://fluttercommunity.dev/_github/header/connectivity_plus_platform_interface)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/connectivity_plus_platform_interface.svg)](https://pub.dev/packages/connectivity_plus_platform_interface)

A common platform interface for [`connectivity_plus`](https://pub.dev/packages/connectivity_plus).

## Usage

This package is already included as part of the `connectivity_plus` package dependency, and will
be included when using `connectivity_plus` as normal.

package io.flutter.plugins.batteryexample.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

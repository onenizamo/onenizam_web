# Battery Plus Platform Interface

[![Flutter Community: battery_plus_platform_interface](https://fluttercommunity.dev/_github/header/battery_plus_platform_interface)](https://github.com/fluttercommunity/community)

[![pub package](https://img.shields.io/pub/v/battery_plus_platform_interface.svg)](https://pub.dev/packages/battery_plus_platform_interface)

A common platform interface for [`battery_plus`](https://pub.dev/packages/battery_plus).

## Usage

This package is already included as part of the `battery_plus` package dependency, and will
be included when using `battery_plus` as normal.

# sensors_plus_example

Demonstrates how to use the sensors_plus plugin.
